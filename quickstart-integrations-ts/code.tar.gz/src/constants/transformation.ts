const TRANSFORMATION_TYPES = [
  { title: "to upper case", value: "TO_UPPER_CASE" },
  { title: "to lower case", value: "TO_LOWER_CASE" },
  { title: "reverse text", value: "REVERSE" },
  { title: "to title case", value: "TO_TITLE_CASE" },
  { title: "to spongebob case", value: "SPONGEBOB_CASE" },
];

export default TRANSFORMATION_TYPES;
